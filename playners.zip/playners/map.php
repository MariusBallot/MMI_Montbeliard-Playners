 <?php 
 $bodyClass = 'map';
 include('templates/header.php');
?>


  <main>
    <div class="wrapper">
      <div class="recherche">
        <div class="zone">
<div style= 'display: flex'>
          <div class="pdp" style = 'background-image:_____'> <!--L'URL DE L'IMAGE VA LÀ --></div>
          <h2>Nom Prénom</h2>
          </div>
          <input type="text" placeholder="rechercher">
          <button>Chercher</button>
        </div>
      </div>
      <div class="carte" style="background-color: white">
        <!-- la map va là -->
      </div>
    </div>

  </main>

  <script src="js/main.js"></script>

</body>

</html>