<!DOCTYPE html>

<head>
  <meta charset="utf-8">
  <title>Playners</title>
  <meta name="viewport" content="width=device-width">
  <link href="css/font-colors.css" rel="stylesheet">
  <link href="css/placement-size-animation.css" rel="stylesheet">
  <link href="css/mediaQueries.css" rel="stylesheet">


</head>

<body class="index">

  <div class="big-screen">
    <h1>POUR UNE MEILLEUR EXPÉRIENCE<br/>
    UTILISEZ CE SITE<br/>AU FORMAT PORTRAIT</h1>
  </div>


  <div class="wraper">
    <div class="parent-logos">
      <img class="logo-white" src="images-contenues/logo-white.png" alt="logo-white">
      <img class="logo-text-white" src="images-contenues/FullTextWhite.svg" alt="FullTextWhite">
    </div>


    <div class="formulaires">
      <div class="buttonsLog">
        <button class="signin" type="button" name="button">INSCRIPTION</button>
        <button class="login" type="button" name="button">CONNEXION</button>
      </div>
      <div class="fillText">
        <form class="inscription" action="index.html" method="post">
          <input type="text" name="Adresse-mail" placeholder="e-mail">
          <input type="text" name="Adresse-mail" placeholder="mot de passe">
          <input type="text" name="Adresse-mail" placeholder="confirmer mot de passe">
          <button class="login-google" type="button" name="button"><img class="logo-g"src="images-contenues/google-plus.svg" alt="google-plus"> <p>S'inscrire avec google+</p></button>
        </form>

        <form class="connexion" action="index.html" method="post">
          <input type="text" name="Adresse-mail" placeholder="e-mail">
          <input type="text" name="Adresse-mail" placeholder="mot de passe">
          <button class="login-google" type="button" name="button"><img class="logo-g"src="images-contenues/google-plus.svg" alt="google-plus"><p>Se connecter avec google+</p></button>
        </form>
      </div>
    </div>


    <button class="submit" type="button" name="button">S'INSCRIRE</button>
  </div>
  <script src="js/main.js"></script>
</body>

</html>