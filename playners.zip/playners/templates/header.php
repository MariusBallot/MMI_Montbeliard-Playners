<!DOCTYPE html>

<head>
    <meta charset="utf-8">
    <title>Playners</title>
    <meta name="viewport" content="width=device-width">
    <link href="css/font-colors.css" rel="stylesheet">
    <link href="css/placement-size-animation.css" rel="stylesheet">
    <link href="css/mediaQueries.css" rel="stylesheet">


</head>

<body class="<?php echo $bodyClass; ?>">
<header>
    <div class="big-screen">
        <h1>POUR UNE MEILLEUR EXPÉRIENCE
            <br/> UTILISEZ CE SITE
            <br/>AU FORMAT PORTRAIT</h1>
    </div>

    <a href="./dashboard.php"><img class="lil-logo" src="images-contenues/logo-white-little.png" alt="logo-white-little"></a>

    <div class="menuButton">
        <img class="menuClosed" src="images-contenues/menuClosed.svg" alt="menuClosed">
        <img class="menuOpened" src="images-contenues/menuOpened.svg" alt="menuOpened">
    </div>

    <nav class="menu">
        <div class="top">
            <img class="lil-logo" src="images-contenues/logo-white-little.png" alt="logo-white-little">
        </div>
        <div class="items">
            <ul>
                <li>
                    <img src="images-contenues/friend-request.svg" alt="friend-request">
                    <a href="dashboard.php">mes coplayners</a>
                </li>
                <li>
                    <img src="images-contenues/placeholder.svg" alt="placeholder">
                    <a href="map.php"> carte</a>
                </li>
                <li>
                    <img src="images-contenues/runner.svg" alt="runner">
                    <a href="training.php">mes entrainement</a>
                </li>
                <li>
                    <img src="images-contenues/trophy.svg" alt="trophy">
                    <a href="achievements.php">mes achievements</a>
                </li>
                <li>
                    <img src="images-contenues/settings.svg" alt="settings">
                    <a href="profil.php">mon profil</a>
                </li>
                <li>
                    <img src="images-contenues/power.svg" alt="power">
                    <a href="index.php">se deconnecter</a>
                </li>
            </ul>
            <p>
                <a href="about.php"> a propos</a>
            </p>
        </div>

    </nav>


</header>