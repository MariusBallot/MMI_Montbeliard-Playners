<?php 
 $bodyClass = 'about';
 include('templates/header.php');
?>
  <main>
    <img src="images-contenues/logo-white.png" alt="logo-white">

    <ul>
      <li>heloise lerenard</li>
      <li>thibeault lepreux</li>
      <li>marius ballot</li>
    </ul>
    <img src="images-contenues/logo-mmi.svg" alt="logo-mmi">

    <p>Projet réalisé dans le cadre d'un exercice pédagogique au département MMi de Montbéliard</p>
  </main>

  <script src="js/main.js"></script>

</body>

</html>